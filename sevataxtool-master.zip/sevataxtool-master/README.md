# Framework-Variabilidad

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.0.4.

Instanciacion de difentes componentes del framework de Variabilidad desarrollado como parte del proyecto de investigacion de "Desarrollo de software basado en reuso" perteneciente al departamento de ingieneria de software, de la facultad de informatica, de la universidad nacional del comahue.

## Probar implementacion

Debemos ejecutar `ng serve` para levantar un servidor interno de pruebas. Luego dirigirse en el navegador a `http://localhost:4200/` y probar lo implementado.

## Estructura temporaria

Por el momento, la herrramienta solo traduce a CNF y posteriormente uno puede decidir si resolver dicha traduccion con SAT.

Por otro lado, la herramienta permite generar del mismo Datasheet de entrada (JSON), una estructura underline mediante otro componente.
