export interface Document {

  stringCuerpo:string;
  escribirRegla(regla:string); //Metodo que agrega a las reglas ya escritas, una nueva.
}
