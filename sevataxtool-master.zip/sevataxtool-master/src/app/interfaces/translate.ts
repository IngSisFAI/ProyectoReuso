export interface Translate{

// TODO: Definir como sera el proceso de esto, quien llama a quien, como etc.
// TODO: Definir tambienla interface de Document.

  traducirJson(json:string):void;
  confeccionarStringFinal():void;
}
