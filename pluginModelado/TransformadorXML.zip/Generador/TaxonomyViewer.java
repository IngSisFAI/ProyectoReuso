package Generador;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

public class TaxonomyViewer extends javax.swing.JFrame {

	private JTree arbolTaxonomia;
	private JTree tree;

	/**
	 * Auto-generated main method to display this JFrame
	 */
	
	public static void main(String[] args) {

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				TaxonomyViewer inst = new TaxonomyViewer();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}

	public TaxonomyViewer() {
		super();
		initGUI();
	}

	private void initGUI() {
	
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			{
				JMenuBar menuBar = new JMenuBar();
				this.setJMenuBar(menuBar);
				JMenu fileMenu = new JMenu("File");
				JMenuItem exitItem = new JMenuItem("Exit ");
				exitItem.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent arg0) {
						System.exit(0);
					}
				});
				fileMenu.add(exitItem);			
				menuBar.add(fileMenu);
				
				this.setDefaultCloseOperation(EXIT_ON_CLOSE);
				setTitle("Taxonomy Explorer");
				Icon leafIcon = new ImageIcon("leaf.gif");
				Icon openIcon = new ImageIcon("open.gif");
				Icon closedIcon = new ImageIcon("closed.gif");

				UIManager.put("Tree.leafIcon", leafIcon);
				UIManager.put("Tree.openIcon", openIcon);
				UIManager.put("Tree.closedIcon", closedIcon);
	
				arbolTaxonomia = createTree();				
			
				getContentPane().add(new JScrollPane(arbolTaxonomia), BorderLayout.CENTER);
				setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
			}
			pack();
			setSize(400, 300);
		} 
		catch (Exception e) {
			// add your error handling code here
			e.printStackTrace();
		}
	}
	
	protected void addWorkspacePanel() {
		
	}

	public JTree createTree() {
	
		// create the child nodes
		TaxonomyExplorer tExplorer = new TaxonomyExplorer();

		// create the tree by passing in the root node
		tree = new JTree(tExplorer.getTree());
		
		/*tree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree
						.getLastSelectedPathComponent();
	
				if (node == null)
					return;

				Object nodeInfo = node.getUserObject();
				System.out.println("Selected:" + nodeInfo.toString());
				String comps = queryForComponents(nodeInfo.toString());			
			}

		});*/
		return tree;
	}

	protected Vector<String> getComponentsFrom(String string) {
		Vector<String> v = new Vector<String>();
		String[] array = string.split("\n");
		for (int i = 0; i < array.length; i++)
			v.add(array[i]);
		return v;
	}

	public void setWorkspace(String text) {
		
		String[] arg = { text };
	}

	private String queryForComponents(String query) {

		return "" ;
	}

	private String preprocessQuery(String query) {
		
		return "";
	}

	private String cleanQuery(String query) {
	
		return query.replaceAll("[^a-zA-Z0-9\\s]", "");
	}
}