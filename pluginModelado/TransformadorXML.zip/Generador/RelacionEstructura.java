package Generador;

public class RelacionEstructura {

	private String relacion;
	private String hijo;
	
	public RelacionEstructura(String r, String h){
		relacion = r;
		hijo = h;
	}
	
	public String getRelacion() {
		return relacion;
	}
	
	public void setRelacion(String relacion) {
		this.relacion = relacion;
	}
	
	public String getHijo() {
		return hijo;
	}
	
	public void setHijo(String hijo) {
		this.hijo = hijo;
	}
}