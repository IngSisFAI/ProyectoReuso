package Generador;

import java.util.ArrayList;

public class Estructura {

	private int estPadre;
	private ArrayList<String> hijos;
	private String relacion;
	
	public Estructura(int p, ArrayList<String> h, String rel){
		estPadre = p;
		setHijos(h);
		relacion = rel;
	}

	public ArrayList<String> getHijos() {
		return hijos;
	}

	public void setHijos(ArrayList<String> hijos) {
		this.hijos = hijos;
	}

	public int getEstPadre() {
		return estPadre;
	}

	public void setEstPadre(int estPadre) {
		this.estPadre = estPadre;
	}

	public String getRelacion() {
		return relacion;
	}

	public void setRelacion(String relacion) {
		this.relacion = relacion;
	}
}