package Generador;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

public class Main {

	public static void main(String[] args) {

		try {
			comienzo();
		} catch (IOException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	private static void comienzo() throws IOException {

		try {

			/** Lectura del archivo .xml en memoria **/
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			System.out.println("Ingresar el path del archivo XML a transformar");
			org.w3c.dom.Document documento = builder.parse(new File(TecladoIn.readLine()));

			/** Obtiene los atributos del nodo raiz **/
			Node nodoRaiz = documento.getFirstChild();
			NamedNodeMap atributos = nodoRaiz.getAttributes();
			Node atributoRaiz = atributos.getNamedItem("name");
			String valorAtributo = atributoRaiz.getNodeValue();

			/** Crea elemento raiz del documento del documento final: doc **/
			Namespace namespace = Namespace.getNamespace("functionality");
			Element datasheet = new Element("Datasheet", namespace);
			datasheet.setAttribute("name",valorAtributo,Namespace.getNamespace("functionality", valorAtributo));
			Document doc = new Document();
			doc.setRootElement(datasheet);

			/** Crea las estructuras necesarias para el manejo de las relaciones **/
			ArrayList<Servicio> servicios = new ArrayList<Servicio>();
			ArrayList<Estructura> estructuras = new ArrayList<Estructura>();
			ArrayList<RelacionSimple> relaciones = new ArrayList<RelacionSimple>();
			ArrayList<Conexion> conexiones = new ArrayList<Conexion>();
			NodeList listaHijos = nodoRaiz.getChildNodes();
			int lon = listaHijos.getLength();

			cargarXmlInt(doc,listaHijos,servicios,estructuras,relaciones,conexiones,0,0,1,lon,datasheet);
			escribirDocumento(datasheet,servicios,estructuras,relaciones,conexiones);
			ServiciosXml(servicios);

			/** Prepara el documento de salida **/
			XMLOutputter salida = new XMLOutputter();
			salida.setFormat(Format.getPrettyFormat());
			// VER DONDE COLOCAR
			salida.output(doc, new FileWriter("/home/mai/Escritorio/DataSheet/Final.xml")); 
			System.out.println("Archivo: " + valorAtributo + " creado");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void escribirDocumento(Element padre,ArrayList<Servicio> servicios,ArrayList<Estructura> estructuras,
			ArrayList<RelacionSimple> relaciones, ArrayList<Conexion> conexiones) {


		/** Crea el namespace para referenciar el primer M_Services del que parte la funcionalidad **/
		String primero = ServicioRaiz(relaciones);
		Namespace namespace = Namespace.getNamespace(primero);
		Element raiz = new Element("M_Service", namespace);
		raiz.setAttribute("name",primero,Namespace.getNamespace("service", primero));
		padre.addContent(raiz);
		
		escribirDocumentoInt(raiz,servicios,estructuras,relaciones,conexiones);
	}

	private static void escribirDocumentoInt(Element padre,ArrayList<Servicio> servicios, ArrayList<Estructura> estructuras,
			ArrayList<RelacionSimple> relaciones, ArrayList<Conexion> conexiones) {
		
		/** Busca si hay algun servicio hijo en "relaciones"(simples) que sea "servicioPadre" de un punto de conexion **/
		Element relSimple = null;
		int longi = conexiones.size();
		Namespace namespace;

		for (int k = 0; k < longi; k++) {
			
			String servicioPadre = servicios.get(conexiones.get(k).getServPadre()).getName();
			int t = relaciones.size();
			
			for (int s = 0; s < t; s++) {
				if (relaciones.get(s).getHijo().equalsIgnoreCase(servicioPadre)) {

					/** Crea el namespace para referenciar el servicio en la relacion simple **/
					namespace = Namespace.getNamespace(conexiones.get(k).getValor());
					relSimple = new Element(relaciones.get(s).getRelacion(),namespace);
					relSimple.setAttribute("name",servicioPadre,Namespace.getNamespace("service", servicioPadre));
					padre.addContent(0,relSimple);
					interno(servicioPadre,relSimple,servicios,estructuras,relaciones,conexiones);
				}	
			}
		}
	}

	private static void interno(String serv,Element padre,ArrayList<Servicio> servicios, ArrayList<Estructura> estructuras,
			ArrayList<RelacionSimple> relaciones, ArrayList<Conexion> conexiones) {
			
	//	Estructura e = buscarEstructura(conexiones.get(k).getEstHijo(),estructuras);
		Estructura e = buscarEstructuraNombre(serv,estructuras,servicios,conexiones);
		if(e != null){
			
			int r = 0, l = e.getHijos().size();
			Element element = null;
			String relE = e.getRelacion();
			Element relacion = new Element("GlobalVariationPoint");
			padre.addContent(relacion);
			
			while (r < l) {	
				String servicioHijo = e.getHijos().get(r);

				/** Crea el namespace para referenciar el servicio hijo en la relacion estructural **/
				Namespace namespace = Namespace.getNamespace(relE);
				element = new Element(relE, namespace);
				element.setAttribute("name",servicioHijo,Namespace.getNamespace("service", servicioHijo));
				relacion.addContent(element);
				interno(servicioHijo,element,servicios,estructuras,relaciones,conexiones);		
				r++;
			}
		}	
		//int lo = variantes.size(), f;
		//for (f = 0; f < lo; f++) 
		//	relacion.addContent(f, variantes.get(f));
		//padre.addContent(relacion);
	/*	if(relSimple != null)
			relSimple.addContent(0,relacion);
		else*/
	}

	private static Estructura buscarEstructuraNombre(String serv, ArrayList<Estructura> estructuras, 
			ArrayList<Servicio> servicios, ArrayList<Conexion> conexiones) {
		
		int longEstructuras = estructuras.size(), i = 0;
		int longConexiones = conexiones.size(), j = 0;
	
		while (j < longConexiones) {
			if(servicios.get(conexiones.get(j).getServPadre()).getName().equalsIgnoreCase(serv)){
				
				while(i<longEstructuras){
					if(conexiones.get(j).getEstHijo()==estructuras.get(i).getEstPadre()){
						return estructuras.get(i);
					}
					i++;
				}
			}
			j++;
		}
		return null;
	}

	private static String ServicioRaiz(ArrayList<RelacionSimple> relaciones) {

		int i = 0, j = 0, l = relaciones.size();
		String servicio = "", aux = "";
		aux = relaciones.get(0).getPadre();

		while (i < l && servicio.isEmpty()) {

			while (j < l && servicio.isEmpty()) {

				if (aux.equalsIgnoreCase(relaciones.get(j).getHijo())) {
					aux = "";
					j = l;
				}
				j++;
			}
			if (!aux.isEmpty())
				servicio = aux;

			j = 0;
			i++;
			if (i < l)
				aux = relaciones.get(i).getPadre();
		}
		return servicio;
	}

	private static void ServiciosXml(ArrayList<Servicio> lista) throws Exception {

		try {
			String nombre, consulta;
			ResultSet result;
			//ConexionBD conexion = new ConexionBD("localhost", "taxonomia", "root", "mailen");
			ConexionBD conexion = new ConexionBD("gisproject.fi.uncoma.edu.ar","taxonomia","uconsulta","uconsulta");
			Connection con = conexion.getConexion();
			Statement statement = (Statement) con.createStatement();
			int lon = lista.size();

			for (int i = 0; i < lon; i++) {

				consulta = "SELECT cat.codigo,cat.descripcion,dom.descripcion,cat.categoriasuperior "
						+ "FROM categoria cat natural join perteneceADomino pert inner join domino dom on pert.idDominio = dom.idDominio "
						+ "WHERE cat.codigo LIKE \'"
						+ lista.get(i).getName()
						+ "\'";
				result = (ResultSet) statement.executeQuery(consulta);

				while (result.next()) {
					nombre = result.getString(1);
					System.out.println("Ingrese el destino de los archivos XML generados");
					String path = TecladoIn.readLine();
					crearXML(path + nombre, result);
				}
				result.close();
			}
			System.out.println(conexion.CerrarConexion());
		} catch (SQLException exc) {
			System.out.println(exc.getMessage());
		}
	}

	private static void crearXML(String nombre, ResultSet result) {

		String cadena, capa, nom;

		try {

			nom = nombre + ".xml";
			File archivo = new File(nom);
			FileWriter escribir = new FileWriter(archivo, true);

			cadena = "<?xml version = \"1.0\"?>";
			escribir.write(cadena);

			capa = result.getString(1);
			cadena = "<Datasheet>";
			escribir.write(cadena);

			cadena = "<ServiceId>";
			escribir.write(cadena);

			cadena = result.getString(1);
			escribir.write(cadena);

			cadena = "</ServiceId>";
			escribir.write(cadena);

			cadena = "<Description>";
			escribir.write(cadena);

			cadena = result.getString(2);
			escribir.write(cadena);

			cadena = "</Description>";
			escribir.write(cadena);

			cadena = "<LayerArchitecture>";
			escribir.write(cadena);

			if (capa.startsWith("HI"))
				cadena = "Human Interaction";
			else if (capa.startsWith("PS"))
				cadena = "User Processing";
			else if (capa.startsWith("MMS"))
				cadena = "Model/Information Management";
			else
				cadena = "None";
			escribir.write(cadena);

			cadena = "</LayerArchitecture>";
			escribir.write(cadena);

			cadena = "<Domain>";
			escribir.write(cadena);

			cadena = result.getString(3);
			escribir.write(cadena);

			cadena = "</Domain>";
			escribir.write(cadena);

			cadena = "<Inherited>";
			escribir.write(cadena);

			cadena = result.getString(4);
			if (cadena == null)
				cadena = "None";
			escribir.write(cadena);

			cadena = "</Inherited>";
			escribir.write(cadena);

			cadena = "</Datasheet>";
			escribir.write(cadena);

			escribir.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	private static void cargarXmlInt(org.jdom2.Document doc,
			NodeList listaHijos, ArrayList<Servicio> servicios,
			ArrayList<Estructura> estructuras,
			ArrayList<RelacionSimple> relaciones,
			ArrayList<Conexion> conexiones, int rel, int j, int i, int lon,
			Element padre) {

		NamedNodeMap atributosHijo;
		Node atributoHijo;
		String valor, valorR;
		String valE;
		int longi, numE, numS;

		if (i < (lon - 1)) {

			Node nodoHijo = listaHijos.item(i);
			String tipoNodo = nodoHijo.getNodeName();
			atributosHijo = nodoHijo.getAttributes();

			while (tipoNodo.equalsIgnoreCase("rootServices")) {

				atributoHijo = atributosHijo.getNamedItem("name");
				valor = atributoHijo.getNodeValue();

				/** Agrega servicio a la lista de servicios,con su numero para referenciarlo **/
				Servicio s = new Servicio();
				s.setName(valor);
				s.setNum(j);
				servicios.add(s);
				j++;
				i = i + 2;
				nodoHijo = listaHijos.item(i);
				tipoNodo = nodoHijo.getNodeName();
				atributosHijo = nodoHijo.getAttributes();
			}

			while (tipoNodo.equalsIgnoreCase("layers")) {
				i = i + 2;
				nodoHijo = listaHijos.item(i);
				tipoNodo = nodoHijo.getNodeName();
				// atributosHijo = nodoHijo.getAttributes();
			}

			switch (tipoNodo) {

			case "relationships":

				String servicioPadre,
				servicioHijo;
				// atributoHijo = atributosHijo.getNamedItem("xsi:type");
				atributoHijo = listaHijos.item(i).getAttributes()
						.getNamedItem("xsi:type");
				valor = atributoHijo.getNodeValue();
				valor = valor.substring(7);
				Estructura est;
				ArrayList<String> hijos;

				switch (valor) {

				case "VariantVP":
					hijos = new ArrayList<String>();
					est = new Estructura(rel, hijos, valor);
					estructuras.add(est);

					i = i + 2;
					rel++;
					cargarXmlInt(doc, listaHijos, servicios, estructuras,
							relaciones, conexiones, rel, j, i, lon, padre);
					break;

				case "AlternativeVP":
					hijos = new ArrayList<String>();
					est = new Estructura(rel, hijos, valor);
					estructuras.add(est);

					i = i + 2;
					rel++;
					cargarXmlInt(doc, listaHijos, servicios, estructuras,
							relaciones, conexiones, rel, j, i, lon, padre);
					break;

				default:

					if (!(valor.equalsIgnoreCase("Requires") || valor.equalsIgnoreCase("Excludes") || 
							valor.equalsIgnoreCase("Uses"))) {
						System.out.println("Error");
						break;
					}

					atributosHijo = nodoHijo.getAttributes();

					/** Obtiene el servicio padre de la relacion simple **/
					atributoHijo = atributosHijo.getNamedItem("fromService");
					valorR = atributoHijo.getNodeValue();
					longi = (valorR.length()) - 1;
					numE = Character.getNumericValue(valorR.charAt(longi));
					servicios.get(numE).setType("Common");
					servicioPadre = servicios.get(numE).getName();

					/** Obtiene el servicio hijo de la relacion simple **/
					atributoHijo = atributosHijo.getNamedItem("toService");
					valorR = atributoHijo.getNodeValue();
					longi = (valorR.length()) - 1;
					numS = Character.getNumericValue(valorR.charAt(longi));
					servicioHijo = servicios.get(numS).getName();

					RelacionSimple rs = new RelacionSimple(servicioPadre,
							valor, servicioHijo);
					rs.setNumero(rel);
					relaciones.add(rs);

					i = i + 2;
					rel++;
					cargarXmlInt(doc, listaHijos, servicios, estructuras,
							relaciones, conexiones, rel, j, i, lon, padre);
					break;
				}
				break;

			case "variabilities":

				servicioPadre = "";
				atributoHijo = atributosHijo.getNamedItem("xsi:type");
				valE = atributoHijo.getNodeValue();
				valE = valE.substring(7);
				numE = rel;
				atributosHijo = nodoHijo.getAttributes();

				/** Obtiene la relacion //@relationship padre de la estructura **/
				atributoHijo = atributosHijo.getNamedItem("fromStructure");
				valor = atributoHijo.getNodeValue();
				longi = (valor.length()) - 1;
				numE = Character.getNumericValue(valor.charAt(longi));

				/** Obtiene el servicio hijo //@rootServices de la relacion **/
				atributoHijo = atributosHijo.getNamedItem("toService");
				valor = atributoHijo.getNodeValue();
				longi = (valor.length()) - 1;
				numS = Character.getNumericValue(valor.charAt(longi));
				servicioHijo = servicios.get(numS).getName();

				setearRelacion(numE, estructuras, servicioHijo);

				i = i + 2;
				cargarXmlInt(doc,listaHijos,servicios,estructuras,relaciones,conexiones,rel,j,i,lon,padre);
				break;

			case "connections":

				atributosHijo = nodoHijo.getAttributes();

				/** Obtiene el servicio padre //@rootServices del punto de conexion **/
				atributoHijo = atributosHijo.getNamedItem("fromService");
				valor = atributoHijo.getNodeValue();
				longi = (valor.length()) - 1;
				numS = Character.getNumericValue(valor.charAt(longi));
				servicios.get(numS).setType("Variant");
				servicioPadre = servicios.get(numS).getName();

				/** Obtiene la estructura del punto de conexion **/
				atributoHijo = atributosHijo.getNamedItem("toStructure");
				valor = atributoHijo.getNodeValue();
				longi = (valor.length()) - 1;
				numE = Character.getNumericValue(valor.charAt(longi));

				Conexion cone = new Conexion(numS, numE, valor);
				conexiones.add(cone);
				i = i + 2;
				cargarXmlInt(doc,listaHijos,servicios,estructuras,relaciones,conexiones,rel,j,i,lon,padre);
				break;
			}
		}
	}
	
	private static Estructura buscarEstructura(int r, ArrayList<Estructura> estructuras) {

		int longi = estructuras.size(), i = 0;

		while (i < longi) {
			if (estructuras.get(i).getEstPadre() == r)
				return estructuras.get(i);
			else
				i++;
		}
		return null;
	}

	private static void setearRelacion(int r, ArrayList<Estructura> estructuras, String relHijo) {

		int longi = estructuras.size(), i = 0;

		while (i < longi) {
			if (estructuras.get(i).getEstPadre() == r) {
				estructuras.get(i).getHijos().add(relHijo);
				i = longi;
			} else
				i++;
		}
	}
}