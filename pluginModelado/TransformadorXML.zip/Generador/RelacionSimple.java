package Generador;

public class RelacionSimple extends Relacion{

	private String padre;
	private String relacion;
	private String hijo;
	
	public RelacionSimple(String p, String r, String h){
		setPadre(p);
		setRelacion(r);
		setHijo(h);
	}

	public String getPadre() {
		return padre;
	}

	public void setPadre(String padre) {
		this.padre = padre;
	}

	public String getRelacion() {
		return relacion;
	}

	public void setRelacion(String relacion) {
		this.relacion = relacion;
	}

	public String getHijo() {
		return hijo;
	}

	public void setHijo(String hijo) {
		this.hijo = hijo;
	}
}