package Generador;

public class Conexion {

	private int servPadre;
	private int estHijo;
	private String valor;
	
	public Conexion(int s, int e, String v){
		servPadre = s;
		estHijo = e;
		valor = v;
	}

	public int getServPadre() {
		return servPadre;
	}

	public void setServPadre(int servPadre) {
		this.servPadre = servPadre;
	}

	public int getEstHijo() {
		return estHijo;
	}

	public void setEstHijo(int estHijo) {
		this.estHijo = estHijo;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}
}