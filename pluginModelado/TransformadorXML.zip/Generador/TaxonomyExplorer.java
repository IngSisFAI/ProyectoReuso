package Generador;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.tree.DefaultMutableTreeNode;

public class TaxonomyExplorer {
	
	private  ConexionBD conexion;
	private  Connection con;
	private  Statement statement;
	private DefaultMutableTreeNode subTree1;
	private DefaultMutableTreeNode root;
	
	public DefaultMutableTreeNode getTree() {
		return root;		
	}

	public TaxonomyExplorer(){
		
		conexion = null;
		try {
			
			/*LA CONEXION DEBE SER AL SERVIDOR, NO A BASE DE DATOS LOCAL*/
			conexion = new ConexionBD("localhost","taxonomia","root","mailen");
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	
		con = conexion.getConexion();
		statement = null;
		root = new DefaultMutableTreeNode("Root");
		subTree1 = new DefaultMutableTreeNode("xCategoria");		
		leerArbolPorCategoria(root,"null");		
		
		try {
			conexion.CerrarConexion();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}  
	
	private void leerArbolPorCategoria(DefaultMutableTreeNode padre,String padreStr){
		
		try {
			
			statement = (Statement) con.createStatement();
			String sql = "";
			
			if(padreStr.equals("null"))
				 sql = "select * from categoria where categoriaSuperior is null";
			else
				 sql = "select * from categoria where categoriaSuperior='" + padreStr + "'";
			
		    // Let us select all the records and display them.
		   	ResultSet rs = statement.executeQuery(sql);		
		   
		    while(rs.next()){       
	            
	     		String code = rs.getString("codigo");
	     		String desc = rs.getString("descripcion");
	            String parent = rs.getString("categoriasuperior");   
	           	            
	            //Display values
	            String dominio = getDominio(code,con);	  		  
	            DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(code + ":" + desc); 
	   	  	    padre.add(childNode);   
	   	  	    
	            leerArbolPorCategoria(childNode,code);
	          }
	     	// root.add(padre);
	     	
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void escribirArchivo(String code, String desc, String parent) {
		
		BufferedWriter writer = null;
        
		try {
            //create a temporary file
        	code = cleanQuery(code);
        	desc = cleanQuery(desc);
        	parent = cleanQuery(parent);
        	if(parent != null)
	        	if(parent.equals("null"))
	        	{
	        		parent = "";
	        	}
            File taxFile = new File("/home/mai/jerarquia/taxonomiaescrita/" + code + "-" + desc + "-" + parent);

            // This will output the full path where the file will be written to...
            System.out.println(taxFile.getCanonicalPath());

            writer = new BufferedWriter(new FileWriter(taxFile));
            writer.write(code + " " + desc + " " + parent);
        } 
		catch (Exception e) {
            e.printStackTrace();
        } 
        finally {
        	try {
                // Close the writer regardless of what happens...
                writer.close();
            } 
        	catch (Exception e) {
            }
        }	
	}

	private String getDominio(String code, Connection con2) {
		
		String sql = "select domino.descripcion from domino NATURAL JOIN perteneceADomino where codigo='" + code + "'";
		String ret = "";
		
		try {
			Statement getDomainStatement = con2.createStatement();	
			ResultSet rs = getDomainStatement.executeQuery(sql);			
		
			while(rs.next()) {    	            
	     		ret += rs.getString("descripcion");                      	          
	         }
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return ret;
	}

	private String cleanQuery(String query) {
		
		if(query != null)
			return query.replaceAll("[^a-zA-Z0-9\\s]", "");
		else
			return null;
	}
}