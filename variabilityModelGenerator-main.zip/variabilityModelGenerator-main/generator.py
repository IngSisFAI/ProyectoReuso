
import model_gen

SQ = 30
RC = 5
MP = 4
IQ = 10

selected_scenarios=[]

model_gen.create_single_datasheet(SQ,RC,MP,IQ,selected_scenarios)